﻿Public Interface observador
    Function actualizar(mensaje As String) As String

End Interface

﻿Public Interface sujeto
    Sub actualizar(mensaje As String)
    Sub notificarObservadores()
    Sub agregarObservadores(ByVal o As observador)
    Sub quitarObservadores(ByVal o As observador)

End Interface

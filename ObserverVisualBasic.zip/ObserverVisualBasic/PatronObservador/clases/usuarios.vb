﻿Imports ObserverVisualBasic

Public Class usuarios
    Implements observador
    Private _sujeto As sujeto
    Private _nombre As String

    Public Function actualizar(mensaje As String) As String Implements observador.actualizar
        Return _nombre + " recibe actualizacion " + mensaje
    End Function
    Public Sub New(ByVal obj As sujeto, ByVal name As String)
        Me._sujeto = obj
        obj.agregarObservadores(Me)
        Me._nombre = name

    End Sub

End Class

﻿Public Class Form1
    Private objTiempo As adminClimas
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        objTiempo = New adminClimas
        Dim m_observador As New usuarios(objTiempo, "John")
        Dim obj2 As New usuarios(objTiempo, "Gustavo")
        objTiempo.actualizar("Cae lluvia en Soachington")

        mostrarInformados()

        objTiempo.quitarObservadores(obj2)
        objTiempo.actualizar("Cae Nieve en Corozal")
        mostrarInformados()

    End Sub
    Private Sub mostrarInformados()
        For Each str As String In objTiempo.mensajesNotificacion
            Me.TextBox1.Text = Me.TextBox1.Text & str & vbNewLine
        Next
    End Sub
End Class

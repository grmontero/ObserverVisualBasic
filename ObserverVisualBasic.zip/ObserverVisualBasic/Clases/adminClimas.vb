﻿Imports ObserverVisualBasic
Public Class adminClimas
    Implements sujeto
    Private _observadores As New List(Of observador)
    Public mensajesNotificacion As New List(Of String)
    Dim _mensaje As String
    Public Sub actualizar(mensaje As String) Implements sujeto.actualizar
        Me._mensaje = mensaje
        notificarObservadores()
    End Sub

    Public Sub notificarObservadores() Implements sujeto.notificarObservadores
        For Each obj As observador In _observadores
            mensajesNotificacion.Add(obj.actualizar(Me._mensaje))
        Next
    End Sub

    Public Sub agregarObservadores(o As observador) Implements sujeto.agregarObservadores
        _observadores.Add(o)

    End Sub

    Public Sub quitarObservadores(o As observador) Implements sujeto.quitarObservadores
        _observadores.Remove(o)
    End Sub
End Class
